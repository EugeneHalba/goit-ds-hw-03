import requests
from bs4 import BeautifulSoup
import json
from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://eugenehalba:1715@cluster0.fpmptjl.mongodb.net/Scientists?retryWrites=true&w=majority",
server_api = ServerApi ('1'))
db = client['Scientists']
authors_collection = db['authors']
quotes_collection = db['quotes']

url = 'https://quotes.toscrape.com/'
response = requests.get(url)
soup = BeautifulSoup(response.text, 'lxml')

author_links = soup.find_all('a', href = True, text='(about)')
quotes_link = soup.find_all('a', href = True, text='(Quotes to Scrape)')
base_url = 'https://quotes.toscrape.com'

def get_author_info(author_url):
    response = requests.get(author_url)
    soup = BeautifulSoup(response.text, 'lxml')

    fullname = soup.find('h3', class_='author-title').text.strip()
    born_date = soup.find('span', class_='author-born-date').text.strip()
    born_location = soup.find('span', class_='author-born-location').text.strip()
    description = soup.find('div', class_='author-description').text.strip()

    return {
        'fullname' : fullname,
        'born_date' : born_date,
        'born_location' : born_location,
        'description' : description,
     }

authors_info = []
for link in author_links:
    author_url = base_url + link['href']
    author_info = get_author_info(author_url)
    authors_info.append(author_info)
 
for author in authors_info:
    print(f"full name: {author['fullname']}")
    print(f"born date: {author['born_date']}")
    print(f"born location: {author['born_location']}")
    print(f"description: {author['description']}")
   
quotes_info = []
quotes = soup.find_all('div', class_='quote')

for quote in quotes:
    tags = [tag.text.strip() for tag in quote.find_all('a', class_='tag')]
    author = quote.find('small', class_='author').text.strip()
    text = quote.find('span', class_='text').text.strip()
    
    quotes_info.append({
        'tags': tags,
        'author': author,
        'text': text
    })
for quote in quotes_info:
    print(f"tags: {', '.join(quote['tags'])}")
    print(f"author: {quote['author']}")
    print(f"quote: {quote['text']}")
    print('===' * 20)

with open('authors.json', 'w', encoding='utf-8') as file:
    json.dump(authors_info, file, ensure_ascii=False, indent=4)
print ('File authors.json succesfuly created')

with open('quotes.json', 'w', encoding='utf-8') as file:
    json.dump(quotes_info, file, ensure_ascii=False, indent=4)
print ('File quotes.json succesfuly created')


with open('quotes.json', 'r', encoding='utf-8') as file:
    quotes_data = json.load(file)
    quotes_collection.insert_many(quotes_data)
with open('authors.json', 'r', encoding='utf-8') as file:
    authors_data = json.load(file)
    authors_collection.insert_many(authors_data)



