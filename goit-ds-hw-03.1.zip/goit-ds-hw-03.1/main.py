from bson.objectid import ObjectId

from pymongo import MongoClient
from pymongo.server_api import ServerApi


client = MongoClient(
"mongodb+srv://eugenehalba:1715@cluster0.fpmptjl.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    server_api=ServerApi('1')
)
db = client.book


result_many = db.cats_03.insert_many(
    [
        {
            "name": "Lama_1",
            "age": 2,
            "features": ["ходить в лоток", "не дає себе гладити", "сірий"],
        },
        {
            "name": "Liza_1",
            "age": 4,
            "features": ["ходить в лоток", "дає себе гладити", "білий"],
        },
    ]
)
print(result_many.inserted_ids)

def find_cat ():
    
    cat_name = input ("Enter the cat name:")
    cat_info = db.cats_03.find_one({"name": cat_name})

    if cat_info:
        print ("Cat informations:")
        for key,value in cat_info.items():
            print (f"{key}: {value}")
    else:
        print (f"Name {cat_name} not found")

def find_all ():    
    cat_info = db.cats_03.find()
    for cat in cat_info:
        print (cat)

def update_age ():
    name = input ("Enter name:")
    new_age = input ("Enter new age:")
    result = db.cats_03.update_one({"name": name},{"$set" : { "age" : new_age}})
    if result.matched_count > 0: 
        print (f"Cats age update to {new_age}. ")
    else:
        print (f"Name {name} not found. ")
   
def update_feature ():
    name = input ("Input name:")
    new_feature = input ("Input new feature:")
    result = db.cats_03.update_one({"name": name},{"$push" : { "features" : new_feature}},
    upsert = True
    )
    if result.matched_count > 0: 
        print (f"Cats feature update to {new_feature}. ")
    else:
        print (f"Name {name} not found. ")

def delete_cat ():
    name = input ("Input name:")
    result = db.cats_03.delete_one({"name": name})
    if result.deleted_count > 0: 
        print (f"Cats informaions who call {name} deleteed. ")
    else:
        print (f"Name {name} not found. ")

def delete_all_cat():
    result = db.cats_03.delete_many({})
    print (f"Deleted {result.deleted_count} records")

# find_cat ()
# find_all ()
# update_age()
# update_feature()
# delete_cat()    
#delete_all_cat ()